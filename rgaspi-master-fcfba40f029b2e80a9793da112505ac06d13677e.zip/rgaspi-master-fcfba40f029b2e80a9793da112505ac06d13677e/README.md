rgaspi: gaspi bindings in R

This project consists of three subprojects organized in separate folders:

1. basiclayer:  the R-C-interface to all necessary GPI2-functions 
2. middlelayer: this layer consists of convenience functions, wrappers and 
                classes around the basic layer 
3. toplayer:    this layer can use the middle and basic layer to implement
                higher level aplications such as distributed matrices
                
Additionally, there is a separate directory 'tests' which contains basic tests
and examples.

#repo can be cloned this way:
git clone git@gitlab.lrz.de:ri72fuv2/rgaspi.git


Before the shared library implementing basiclayer can be used, one has to enter the folder rgaspi/basic and
follow the compilation instructions as described in the file compile_notes.txt which can also be found in that 
directory.
